<?

/*

Plugin Name: SITTI Ads Plugin

Plugin URI: http://www.sitibelajar.com

Description: A wordpress plugin to display SITTI Ads

Version: 1.0

Author: Amien Krisna

Author URI: http://www.sitibejalar.com

License: GPL2

*/



/*  Copyright 2010  Amien Krisna  (email : amienz@gmail.com)



    This program is free software; you can redistribute it and/or modify

    it under the terms of the GNU General Public License, version 2, as

    published by the Free Software Foundation.



    This program is distributed in the hope that it will be useful,

    but WITHOUT ANY WARRANTY; without even the implied warranty of

    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

    GNU General Public License for more details.



    You should have received a copy of the GNU General Public License

    along with this program; if not, write to the Free Software

    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/





/* Call the JS to display Ads */



function display_ads() {
echo '
<div class="adsSitti">
<script>
var sitti_pub_id = "'.get_option('publisher_id').'";

var sitti_ad_width = "'.get_option('width').'";

var sitti_ad_height = "'.get_option('height').'";

var sitti_ad_type = "'.get_option('tipe').'";

var sitti_ad_number = "'.get_option('number').'";

var sitti_ad_name = "'.get_option('ad_name').'";

var sitti_dep_id = "'.get_option('slot_id').'";

    </script>
    <script src="http://202.52.131.5/delivery/sittiad.js"></script>
</div>
';

}



/* Fix Compatibility Issues */

 function widget_SITTIAds($args) {

  extract($args);



  $options = get_option("widget_SITTIAds");

  if (!is_array( $options ))

	{

	$options = array(

    	  'title' => 'My Widget Title'

      	);

  	}



  echo $before_widget;

  echo $before_title;?>SITTI Ads<?php echo $after_title;

  display_ads();

  echo $after_widget;

}



/* Activate Options Panel */

function SITTIAds_control()

{

  $options = get_option("widget_SITTIAds");

  if (!is_array( $options ))

  {

    $options = array(

   'title' => 'SITTIZen Network ID'

   );

 }



?>

  <p>

    <label for="myHelloWorld-WidgetTitle">Widget Title: </label>

    <input type="text" id="myHelloWorld-WidgetTitle" name="myHelloWorld-WidgetTitle" value="<?php echo $options['title'];?>" />

  </p>

<?php

}



 /* Initiallize & Register on Admin Bar */

function SITTIAds_init()

{

  register_sidebar_widget(__('SITTI Ads'), 'widget_SITTIAds');

  register_widget_control(   'SITTI Ads Panel', 'SITTIAds_control', 400, 300 );

}





/* Administration */



add_action('admin_menu', 'my_plugin_menu');



function my_plugin_menu() {



  add_options_page('SITTI Ads Options', 'SITTI Ads Manager', 'manage_options', 'my-unique-identifier', 'my_plugin_options');



}



function my_plugin_options() {



  if (!current_user_can('manage_options'))  {

    wp_die( __('You do not have sufficient permissions to access this page.') );

  }



  echo '<div class="wrap">';

  echo '<img src="http://kamisitti.com/wp-content/uploads/2010/09/logo_template1.png"/><h2>Ad Settings</h2>';
  echo '<br/><br/>';

  //echo '<h2>SITTI Ad Settings</h2>';

  echo "Masukkan ID Publisher, Slot ID Iklan & Nama Iklan untuk mengaktifkan plugin SITTI untuk blog wordpress Anda.";

  echo '<form method="post" action="options.php">';

  wp_nonce_field('update-options');

  echo '<table class="form-table">';

  echo '<tr valign="top">';
  echo'<th scope="row">ID Publisher</th>';
  echo '<td><input type="text" name="publisher_id" value="'.get_option('publisher_id').'" size="30"/>
         <a href="http://www.belajarsitti.com" target="_BLANK">Klik disini untuk lihat ID Publisher Anda</a></td></tr>';

  echo'<th scope="row">Nama Iklan</th>';
  echo '<td><input type="text" name="ad_name" value="'.get_option('ad_name').'" size="50"/></td></tr>';


  echo'<th scope="row">Slot ID Iklan</th>';
  echo '<td><input type="text" name="slot_id" value="'.get_option('slot_id').'" size="30"/>
           <a href="http://www.belajarsitti.com" target="_BLANK">Klik disini untuk lihat Slot ID Iklan Anda</a></td></tr>';


  echo'<th scope="row">Tipe Iklan</th>';

  echo '<td>';
        echo '<select name="type" id="type">';
             echo '<option value="300.250.3.1">300 X 250 (3 Iklan)</option>';  //value="width.height.number.type"
             echo '<option value="336.300.3.2">336 X 300 (3 Iklan)</option>';
             echo '<option value="728.90.4.3">728 X 90 (4 Iklan)</option>';
             echo '<option value="160.600.6.4">160 X 600 (6 Iklan)</option>';
             echo '<option value="610.60.2.5">610 X 60 (2 Iklan)</option>';
             echo '<option value="300.160.2.6">300 X 160 (2 Iklan)</option>';
             echo '<option value="940.90.4.7">940 X 90 (4 Iklan)</option>';
             echo '<option value="520.70.2.8">520 X 70 (2 Iklan)</option>';
        echo '</select>';
        echo '<script>document.getElementById("type").value="'.get_option('width').'.'.get_option('height').'.'.get_option('number').'.'.get_option('tipe').'"</script>';
  echo '</td></tr>';

  echo '<table>';
  echo '<input type="hidden" name="action" value="update" />';

  echo '<p class="submit">';

  echo '<input type="submit" value="Ubah" name="submit" class="button-primary">';

  echo '</p>';

  echo '</form><br><br>';

  echo '</div>';

}



 /* Call WP Function to Execute */



$option_name1 = 'publisher_id';
$option_name2 = 'width';
$option_name3 = 'height';
$option_name4 = 'slot_id';
$option_name5 = 'number';
$option_name6 = 'ad_name';
$option_name7 = 'tipe';

if($_POST['publisher_id']!=""){
 	update_option($option_name1, $_POST['publisher_id']);
}else{
	update_option($option_name1, get_option('publisher_id'));
}

if($_POST['ad_name']!=""){
 	update_option($option_name6, $_POST['ad_name']);
}else{
	update_option($option_name6, get_option('ad_name'));
}

if($_POST['slot_id']!=""){
 	update_option($option_name4, $_POST['slot_id']);
}else{
	update_option($option_name4, get_option('slot_id'));
}

$explode=explode('.', $_POST['type']);
$width = $explode[0];
$height = $explode[1];
$number = $explode[2];
$tipe = $explode[3];

if($_POST['type']!=""){

 	update_option($option_name2, $width);
        update_option($option_name3, $height);
        update_option($option_name5, $number);
        update_option($option_name7, $tipe);
}else{
	update_option($option_name2, get_option('width'));
        update_option($option_name3, get_option('height'));
        update_option($option_name5, get_option('number'));
        update_option($option_name7, get_option('tipe'));
}

add_action("plugins_loaded", "SITTIAds_init");



?>






















































